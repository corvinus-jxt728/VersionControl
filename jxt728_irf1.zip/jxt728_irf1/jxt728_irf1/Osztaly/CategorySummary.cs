﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jxt728_irf1.Osztaly
{
    class CategorySummary
    {
        public string Name { get; set; }
        public int NbrOfSales { get; set; }
        public decimal TotalSales { get; set; }

    }
}
